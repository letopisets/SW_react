import Hero from "../content/hero"
import Content_Text from "../content/content_text"
import Friends from "../content/friends"
const Content = () => {
    return (
        <main className="clearfix">
            <Hero/>
            <Friends/>
            <Content_Text/>  
        </main>
    )
}
export default Content