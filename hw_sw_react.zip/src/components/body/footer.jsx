const Footer = () => {
    return (
        <footer class="rounded-bottom-4 row align-items-center">
            <div class="btn btn-danger col-2 offset-4">Send me an <span class="text-black text-uppercase">email</span></div>
        </footer>
    )
}
export default Footer