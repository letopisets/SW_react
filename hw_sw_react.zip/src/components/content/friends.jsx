const Friends = () => {
    return(
        <section className="float-end w-50 row border rounded-bottom-4 ms-2 me-0">
            <h2 className="col-12 text-center">Dream team</h2>
            <img className="col-4 p-1" src="./src/assets/friend1.jpg" alt="Friend"/>
            <img className="col-4 p-1" src="./src/assets/friend2.jpg" alt="Friend"/>
            <img className="col-4 p-1" src="./src/assets/friend3.jpg" alt="Friend"/>
            <img className="col-4 p-1" src="./src/assets/friend4.jpg" alt="Friend"/>
            <img className="col-4 p-1" src="./src/assets/friend5.jpg" alt="Friend"/>
            <img className="col-4 p-1" src="./src/assets/friend6.jpg" alt="Friend"/>
            <img className="col-4 p-1 bottomLeft" src="./src/assets/friend7.jpg" alt="Friend"/>
            <img className="col-4 p-1" src="./src/assets/friend8.jpg" alt="Friend"/>
            <img className="col-4 p-1 bottomRight" src="./src/assets/friend9.jpg" alt="Friend"/>
        </section>
    )
}

export default Friends